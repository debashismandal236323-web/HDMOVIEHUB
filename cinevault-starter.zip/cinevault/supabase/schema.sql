create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.movies (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  synopsis text,
  release_year int,
  language text,
  genres text[] not null default '{}',
  poster_url text,
  source_key text,
  hls_key text,
  status text not null default 'draft'
    check (status in ('draft','uploading','processing','published','failed')),
  rights_confirmed boolean not null default false,
  rights_reference text,
  allow_download boolean not null default false,
  duration_seconds int,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  published_at timestamptz
);

create index if not exists movies_status_created_idx on public.movies(status, created_at desc);
create index if not exists movies_genres_idx on public.movies using gin(genres);

alter table public.profiles enable row level security;
alter table public.movies enable row level security;

create policy "profiles read own" on public.profiles
  for select using (auth.uid() = id);

create policy "published movies visible to everyone" on public.movies
  for select using (status = 'published');

-- Admin writes are performed only by trusted server routes using the service role.
-- Never ship SUPABASE_SERVICE_ROLE_KEY to a client.
