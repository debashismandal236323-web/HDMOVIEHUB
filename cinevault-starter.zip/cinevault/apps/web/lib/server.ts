import { createClient } from '@supabase/supabase-js';
import { S3Client } from '@aws-sdk/client-s3';
export const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {auth:{persistSession:false}});
export const r2 = new S3Client({
 region:'auto',
 endpoint:`https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
 credentials:{accessKeyId:process.env.R2_ACCESS_KEY_ID!,secretAccessKey:process.env.R2_SECRET_ACCESS_KEY!}
});
export const bucket = process.env.R2_BUCKET!;
