export default function Admin(){
 return <main className="shell"><nav className="nav"><a className="brand" href="/">CINEVAULT</a><span>ADMIN CONSOLE</span></nav>
 <section className="hero"><div className="eyebrow">CONTENT MANAGEMENT</div><h1>Movie control room.</h1>
 <p className="muted">The starter dashboard endpoint is ready for an authenticated admin upload form. Connect Supabase Auth, then add title, slug, rights reference and video file fields.</p>
 <p><a className="button" href="/">View storefront</a></p></section>
 <h2>Publishing pipeline</h2><p className="muted">Upload → Private storage → FFmpeg HLS processing → Published catalogue.</p></main>
}
