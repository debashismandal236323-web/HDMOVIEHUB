const demo = [
  {title:'Featured Premiere',year:'2026',genre:'Drama'},
  {title:'The Last Horizon',year:'2025',genre:'Adventure'},
  {title:'Midnight Signal',year:'2024',genre:'Thriller'},
  {title:'Golden Monsoon',year:'2025',genre:'Romance'},
  {title:'Beyond the Valley',year:'2023',genre:'Documentary'},
];
export default function Home(){
 return <main className="shell">
  <nav className="nav"><a className="brand" href="/">CINEVAULT</a><div>Movies　 Series　 My List　 <a href="/admin">Admin</a></div></nav>
  <section className="hero"><div className="eyebrow">A WORLD OF CINEMA</div><h1>Stories worth staying in for.</h1><p className="muted">Discover a curated collection of movies, ready to stream in high quality.</p><a className="button" href="#catalog">Explore movies</a></section>
  <h2 className="section-title" id="catalog">Recently added</h2>
  <div className="grid">{demo.map((m)=><article className="card" key={m.title}><div className="poster">{m.genre}</div><h3>{m.title}</h3><p className="muted">{m.year} · {m.genre}</p></article>)}</div>
  <footer className="footer">© {new Date().getFullYear()} CineVault. Only authorized content is distributed.</footer>
 </main>
}
