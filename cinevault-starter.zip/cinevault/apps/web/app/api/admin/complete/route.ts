import { NextRequest,NextResponse } from 'next/server';
import { Queue } from 'bullmq';
import { supabaseAdmin } from '@/lib/server';
const queue=new Queue('video-processing',{connection:{url:process.env.REDIS_URL!} as never});
export async function POST(req:NextRequest){
 try{
  const {movieId}=await req.json();
  if(typeof movieId!=='string') return NextResponse.json({error:'movieId required'},{status:400});
  const {data,error}=await supabaseAdmin.from('movies').update({status:'processing'}).eq('id',movieId).eq('status','uploading').select('id,source_key,rights_confirmed').single();
  if(error||!data) return NextResponse.json({error:'Movie not found or not awaiting completion'},{status:404});
  if(!data.rights_confirmed) return NextResponse.json({error:'Distribution rights not confirmed'},{status:403});
  await queue.add('transcode',{movieId:data.id,sourceKey:data.source_key},{attempts:3,backoff:{type:'exponential',delay:5000},removeOnComplete:100});
  return NextResponse.json({queued:true});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Request failed'},{status:400});}
}
