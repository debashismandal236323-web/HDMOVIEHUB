import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { randomUUID } from 'crypto';
import { r2, bucket, supabaseAdmin } from '@/lib/server';

const Body = z.object({
 title:z.string().min(1).max(180), slug:z.string().min(1).max(200).regex(/^[a-z0-9-]+$/),
 rightsConfirmed:z.literal(true), rightsReference:z.string().min(3),
 contentType:z.enum(['video/mp4','video/quicktime','video/x-matroska'])
});

// Add real Supabase bearer-token verification and admin-role check before production use.
export async function POST(req:NextRequest){
 try{
  const body=Body.parse(await req.json());
  const sourceKey=`original/${randomUUID()}`;
  const {data,error}=await supabaseAdmin.from('movies').insert({
   title:body.title,slug:body.slug,source_key:sourceKey,status:'uploading',
   rights_confirmed:true,rights_reference:body.rightsReference
  }).select('id').single();
  if(error) throw error;
  const uploadUrl=await getSignedUrl(r2,new PutObjectCommand({Bucket:bucket,Key:sourceKey,ContentType:body.contentType}),{expiresIn:900});
  return NextResponse.json({movieId:data.id,sourceKey,uploadUrl,expiresIn:900});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}
}
