import { Worker } from 'bullmq';
import { createClient } from '@supabase/supabase-js';
import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import { pipeline } from 'node:stream/promises';
import { createWriteStream, createReadStream } from 'node:fs';
import { mkdir, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';

const db=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.SUPABASE_SERVICE_ROLE_KEY!);
const s3=new S3Client({region:'auto',endpoint:`https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,credentials:{accessKeyId:process.env.R2_ACCESS_KEY_ID!,secretAccessKey:process.env.R2_SECRET_ACCESS_KEY!}});
const bucket=process.env.R2_BUCKET!;
const redisUrl=new URL(process.env.REDIS_URL??'redis://localhost:6379');
const connection={host:redisUrl.hostname,port:Number(redisUrl.port||6379),password:redisUrl.password||undefined};

function run(cmd:string,args:string[]){
 return new Promise<void>((resolve,reject)=>{
  const p=spawn(cmd,args,{stdio:'inherit'});
  p.on('error',reject); p.on('close',code=>code===0?resolve():reject(new Error(`${cmd} exited ${code}`)));
 });
}
const worker=new Worker('video-processing',async job=>{
 const {movieId,sourceKey}=job.data as {movieId:string;sourceKey:string};
 const work=join(tmpdir(),`cinevault-${movieId}`);
 const input=join(work,'source.mp4'); const out=join(work,'hls');
 try{
  await mkdir(out,{recursive:true});
  const object=await s3.send(new GetObjectCommand({Bucket:bucket,Key:sourceKey}));
  if(!object.Body) throw new Error('Source object is empty');
  await pipeline(object.Body as NodeJS.ReadableStream,createWriteStream(input));
  await run('ffmpeg',['-y','-i',input,'-vf','scale=w=1280:h=-2:force_original_aspect_ratio=decrease','-c:v','libx264','-preset','veryfast','-crf','23','-c:a','aac','-b:a','128k','-hls_time','6','-hls_playlist_type','vod','-hls_segment_filename',join(out,'segment_%05d.ts'),join(out,'index.m3u8')]);
  const hlsKey=`hls/${movieId}/`;
  for(const file of await readdir(out)){
   await s3.send(new PutObjectCommand({Bucket:bucket,Key:hlsKey+file,Body:createReadStream(join(out,file)),ContentType:file.endsWith('.m3u8')?'application/vnd.apple.mpegurl':'video/mp2t'}));
  }
  const {error}=await db.from('movies').update({status:'published',hls_key:hlsKey,published_at:new Date().toISOString()}).eq('id',movieId).eq('rights_confirmed',true);
  if(error) throw error;
 }catch(error){
  await db.from('movies').update({status:'failed'}).eq('id',movieId);
  throw error;
 }finally{await rm(work,{recursive:true,force:true});}
},{connection});
worker.on('completed',job=>console.log('Published processing job',job.id));
worker.on('failed',(job,err)=>console.error('Processing failed',job?.id,err));
console.log('CineVault video worker listening');
