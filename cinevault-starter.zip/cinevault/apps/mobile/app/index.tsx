import { StatusBar } from 'expo-status-bar';
import { ScrollView,Text,View,Pressable } from 'react-native';
const gold='#d7b56d',muted='#a6a7b0';
const titles=['The Last Horizon','Midnight Signal','Golden Monsoon','Beyond the Valley'];
export default function Home(){
 return <ScrollView style={{flex:1,backgroundColor:'#08090d'}} contentContainerStyle={{padding:22,paddingTop:65}}>
  <StatusBar style="light"/>
  <Text style={{color:gold,fontSize:20,fontWeight:'900',letterSpacing:4}}>CINEVAULT</Text>
  <Text style={{color:'#fff',fontSize:38,fontWeight:'800',marginTop:38}}>Stories worth staying in for.</Text>
  <Text style={{color:muted,lineHeight:24,marginTop:12}}>A premium home for your licensed movie collection.</Text>
  <Pressable style={{backgroundColor:gold,padding:14,borderRadius:8,alignSelf:'flex-start',marginTop:22}}><Text style={{color:'#111',fontWeight:'800'}}>Explore movies</Text></Pressable>
  <Text style={{color:'#fff',fontSize:22,fontWeight:'700',marginTop:42,marginBottom:16}}>Recently added</Text>
  {titles.map((title,i)=><View key={title} style={{backgroundColor:'#171820',borderColor:'#30313a',borderWidth:1,borderRadius:12,padding:18,marginBottom:12}}>
   <Text style={{color:gold,fontSize:11,letterSpacing:2}}>FEATURED TITLE 0{i+1}</Text><Text style={{color:'#fff',fontSize:18,fontWeight:'700',marginTop:8}}>{title}</Text><Text style={{color:muted,marginTop:5}}>Movie details and playback will load from the CineVault API.</Text>
  </View>)}
 </ScrollView>
}
