# CineVault

A starter monorepo for a licensed-movie streaming platform with a Next.js website/admin,
Expo Android app, Supabase database/auth, Cloudflare R2 storage, and a BullMQ/FFmpeg worker.

## Apps
- `apps/web`: Next.js web app and admin API routes
- `apps/mobile`: Expo React Native Android app
- `apps/worker`: background video processing worker
- `supabase/schema.sql`: database tables, indexes, and Row Level Security

## Prerequisites
- Node.js 20+
- pnpm 9+
- Docker (for local Redis)
- Supabase project
- Cloudflare R2 bucket and S3-compatible credentials
- FFmpeg installed on the worker host

## Setup
1. Copy `.env.example` to `.env` and fill in the credentials.
2. Run `pnpm install`.
3. Apply `supabase/schema.sql` to your Supabase project.
4. Start Redis: `docker compose up -d redis`.
5. Start web: `pnpm --filter web dev`.
6. Start worker: `pnpm --filter worker dev`.
7. Start Android app: `pnpm --filter mobile start` and open it with Expo Go or an Android emulator.

## Upload and publishing
The admin upload endpoint creates a private R2 upload URL and a `processing` movie record.
The client uploads directly to R2, then calls the completion endpoint. The worker downloads
the source, creates HLS output, uploads the HLS files, and marks the movie `published` only
when processing succeeds and `rights_confirmed` is true.

For production, add malware scanning, upload size limits, rate limits, signed playback URLs,
moderation/audit logs, retention policies, and a proper job retry/dead-letter strategy.
Never expose Supabase service-role or R2 secret keys to the browser/mobile app.

## Important production notes
- This is a runnable starter scaffold, not a fully hosted production service.
- Configure your Supabase Auth users and promote trusted accounts to `admin` in the `profiles` table.
- HLS playback URLs should be protected using short-lived signed URLs or an authenticated CDN token.
- Confirm the license territory, term, streaming rights, and download rights for each title.
- Use only posters, metadata, subtitles, and video files you are authorized to distribute.
